# Friday Night Funkin': Summer Break Special
![](/_polymod_icon.png)

ANOTHER azumanga mod to the ever-expanding pile - made as a mod folder for the Friday Night Funkin' V-Slice (aka base game)

## what's added in this?
- MOST menus overhauled and/or changed (inspired by Azumanga Donjara Daioh (PS1) and Azumanga Daioh Advance (GBA))
- full week against tomo
- one bonus song (scary...)

## who worked on this?
- [neontflame](https://twitter.com/NeonThFl) (that's me!) - Artist, animator, musician, coder, charter
- [THEINDIGO173](https://twitter.com/THEINDIGO1) - Musician
- [SketcherSquared](https://twitter.com/SketcherSquared) - Artist
- [Dex Dousky](https://twitter.com/Dex_Dousky) - Assistant musician
